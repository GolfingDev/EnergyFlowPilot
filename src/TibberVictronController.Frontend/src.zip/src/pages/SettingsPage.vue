<script setup lang="ts">
import { computed, onMounted, ref } from 'vue';

interface ControllerStatusResponseDto {
  status: string;
  knownSettingsCount: number;
  persistedSettingsCount: number;
  configuredSensitiveSettingsCount: number;
  generatedAtUtc: string;
  victronMqttStatus: string | null;
  victronMqttLastError: string | null;
  victronMqttLastSuccessfulMessageAtUtc: string | null;
}

interface ControllerSettingResponseDto {
  key: string;
  value: string | null;
  isSensitive: boolean;
  isConfigured: boolean;
  updatedAtUtc: string;
}

interface ControllerSettingsResponseDto {
  settings: ControllerSettingResponseDto[];
}

interface UpdateControllerSettingRequestDto {
  value: string | null;
}

interface SettingMetadataDto {
  key: string;
  displayName: string;
  description: string;
  group: string;
  inputKind: string;
  unit: string | null;
  isSensitive: boolean;
  defaultValue: string | null;
}

interface GuiMetadataResponseDto {
  settings: SettingMetadataDto[];
}

interface SettingsErrorDto {
  message: string;
}

interface FieldDefinition {
  key: string;
  section: SectionKey;
  category: 'Normal' | 'Important' | 'Safety Critical';
  helperText?: string;
}

type SectionKey =
  | 'battery'
  | 'price'
  | 'forecast'
  | 'consumption'
  | 'decision'
  | 'system';

interface SectionDefinition {
  key: SectionKey;
  title: string;
  description: string;
}

const sectionDefinitions: SectionDefinition[] = [
  {
    key: 'battery',
    title: 'Battery',
    description: 'Capacity, SoC limits, power and efficiency constraints.'
  },
  {
    key: 'price',
    title: 'Price / Tibber',
    description: 'Tibber token and price-horizon related settings.'
  },
  {
    key: 'forecast',
    title: 'PV / Forecast',
    description: 'Forecast provider, coordinates and planning-only PV inputs.'
  },
  {
    key: 'consumption',
    title: 'Consumption / Load',
    description: 'Average load assumptions used for forecast planning.'
  },
  {
    key: 'decision',
    title: 'Decision Engine',
    description: 'Planning behavior and decision-sensitive thresholds.'
  },
  {
    key: 'system',
    title: 'System / Safety',
    description: 'Controller runtime, MQTT and system safety related values.'
  }
];

const fieldDefinitions: FieldDefinition[] = [
  { key: 'battery.totalCapacityKwh', section: 'battery', category: 'Safety Critical' },
  { key: 'battery.minimumStateOfChargePercent', section: 'battery', category: 'Safety Critical', helperText: 'Hard lower safety limit for the battery.' },
  { key: 'battery.planningMinimumStateOfChargePercent', section: 'battery', category: 'Important' },
  { key: 'battery.planningMaximumStateOfChargePercent', section: 'battery', category: 'Safety Critical', helperText: 'Very high values can leave too little headroom for PV.' },
  { key: 'battery.targetEndStateOfChargePercent', section: 'battery', category: 'Important' },
  { key: 'battery.maximumChargePowerWatts', section: 'battery', category: 'Safety Critical' },
  { key: 'battery.maximumDischargePowerWatts', section: 'battery', category: 'Safety Critical' },
  { key: 'battery.roundTripEfficiencyPercent', section: 'battery', category: 'Important' },
  { key: 'tibber.accessToken', section: 'price', category: 'Safety Critical', helperText: 'Token stays masked and is never shown in clear text again.' },
  { key: 'tibber.homeSelection', section: 'price', category: 'Normal' },
  { key: 'forecast.horizonHours', section: 'price', category: 'Important' },
  { key: 'gridFeedIn.compensationPricePerKwh', section: 'price', category: 'Important' },
  { key: 'pvForecast.provider', section: 'forecast', category: 'Normal' },
  { key: 'pvForecast.apiEndpoint', section: 'forecast', category: 'Important' },
  { key: 'pvForecast.latitude', section: 'forecast', category: 'Important' },
  { key: 'pvForecast.longitude', section: 'forecast', category: 'Important' },
  { key: 'pvForecast.peakPowerKwp', section: 'forecast', category: 'Important' },
  { key: 'pvForecast.declinationDegrees', section: 'forecast', category: 'Normal' },
  { key: 'pvForecast.azimuthDegrees', section: 'forecast', category: 'Normal' },
  { key: 'pvForecast.timeZone', section: 'forecast', category: 'Normal' },
  { key: 'consumptionForecast.averageDailyConsumptionKwh', section: 'consumption', category: 'Important' },
  { key: 'consumptionForecast.timeZone', section: 'consumption', category: 'Normal' },
  { key: 'battery.planningMinimumStateOfChargePercent', section: 'decision', category: 'Important', helperText: 'Planning limits are used by the forecast engine. Absolute limits are used as hard safety constraints.' },
  { key: 'battery.planningMaximumStateOfChargePercent', section: 'decision', category: 'Safety Critical', helperText: 'Planning limits are used by the forecast engine. Absolute limits are used as hard safety constraints.' },
  { key: 'battery.targetEndStateOfChargePercent', section: 'decision', category: 'Important' },
  { key: 'victron.staleAfterSeconds', section: 'system', category: 'Safety Critical' },
  { key: 'victron.keepAliveSeconds', section: 'system', category: 'Important' },
  { key: 'decisionLog.retentionDays', section: 'system', category: 'Normal' },
  { key: 'victron.host', section: 'system', category: 'Safety Critical' },
  { key: 'victron.port', section: 'system', category: 'Important' },
  { key: 'victron.portalId', section: 'system', category: 'Important' },
  { key: 'victron.dryRun', section: 'system', category: 'Safety Critical', helperText: 'Shadow Mode equivalent. Keeps calculation active without driving hardware writes.' }
];

const requiredKeys = new Set([
  'tibber.accessToken',
  'battery.totalCapacityKwh',
  'victron.host'
]);

const settings = ref<ControllerSettingResponseDto[]>([]);
const metadata = ref<GuiMetadataResponseDto | null>(null);
const status = ref<ControllerStatusResponseDto | null>(null);
const draftValues = ref<Record<string, string>>({});
const initialValues = ref<Record<string, string>>({});
const isLoading = ref(false);
const isSaving = ref(false);
const saveSuccess = ref(false);
const pageError = ref<string | null>(null);

const metadataByKey = computed(() => {
  return new Map((metadata.value?.settings ?? []).map((entry) => [entry.key, entry]));
});

const settingByKey = computed(() => {
  return new Map(settings.value.map((entry) => [entry.key, entry]));
});

const availableFieldDefinitions = computed(() => {
  return fieldDefinitions.filter((definition) => metadataByKey.value.has(definition.key));
});

const sections = computed(() => {
  return sectionDefinitions
    .map((section) => ({
      ...section,
      fields: availableFieldDefinitions.value.filter((field) => field.section === section.key)
    }))
    .filter((section) => section.fields.length > 0);
});

const draftValidationErrors = computed(() => {
  const errors: string[] = [];
  const batteryTotalCapacity = getNumericDraftValue('battery.totalCapacityKwh');
  const minimumSoc = getNumericDraftValue('battery.minimumStateOfChargePercent');
  const planningMinimumSoc = getNumericDraftValue('battery.planningMinimumStateOfChargePercent');
  const planningMaximumSoc = getNumericDraftValue('battery.planningMaximumStateOfChargePercent');
  const targetEndSoc = getNumericDraftValue('battery.targetEndStateOfChargePercent');
  const roundTripEfficiency = getNumericDraftValue('battery.roundTripEfficiencyPercent');
  const maximumChargePower = getNumericDraftValue('battery.maximumChargePowerWatts');
  const maximumDischargePower = getNumericDraftValue('battery.maximumDischargePowerWatts');

  if (batteryTotalCapacity !== null && batteryTotalCapacity <= 0) {
    errors.push('Total Capacity kWh must be greater than 0.');
  }

  if (minimumSoc !== null && (minimumSoc < 0 || minimumSoc > 100)) {
    errors.push('Minimum SoC must be between 0 and 100.');
  }

  if (planningMinimumSoc !== null && minimumSoc !== null && planningMinimumSoc < minimumSoc) {
    errors.push('Planning Minimum SoC must be greater than or equal to Minimum SoC.');
  }

  if (planningMaximumSoc !== null && planningMaximumSoc > 100) {
    errors.push('Planning Maximum SoC must be less than or equal to 100.');
  }

  if (planningMaximumSoc !== null && planningMinimumSoc !== null && planningMaximumSoc <= planningMinimumSoc) {
    errors.push('Planning Maximum SoC must be greater than Planning Minimum SoC.');
  }

  if (
    targetEndSoc !== null &&
    planningMinimumSoc !== null &&
    planningMaximumSoc !== null &&
    (targetEndSoc < planningMinimumSoc || targetEndSoc > planningMaximumSoc)
  ) {
    errors.push('Target End SoC must stay between Planning Minimum SoC and Planning Maximum SoC.');
  }

  if (roundTripEfficiency !== null && (roundTripEfficiency < 50 || roundTripEfficiency > 100)) {
    errors.push('Round Trip Efficiency must be between 50 and 100.');
  }

  if (maximumChargePower !== null && maximumChargePower <= 0) {
    errors.push('Maximum Charge Power must be greater than 0.');
  }

  if (maximumDischargePower !== null && maximumDischargePower <= 0) {
    errors.push('Maximum Discharge Power must be greater than 0.');
  }

  if (maximumChargePower !== null && maximumChargePower < 0) {
    errors.push('Charge power cannot be negative.');
  }

  if (maximumDischargePower !== null && maximumDischargePower < 0) {
    errors.push('Discharge power cannot be negative.');
  }

  return Array.from(new Set(errors));
});

const warningMessages = computed(() => {
  const warnings: string[] = [];
  const minimumSoc = getNumericDraftValue('battery.minimumStateOfChargePercent');
  const planningMinimumSoc = getNumericDraftValue('battery.planningMinimumStateOfChargePercent');
  const planningMaximumSoc = getNumericDraftValue('battery.planningMaximumStateOfChargePercent');
  const keepAliveSeconds = getNumericDraftValue('victron.keepAliveSeconds');
  const staleAfterSeconds = getNumericDraftValue('victron.staleAfterSeconds');

  if (minimumSoc !== null && planningMinimumSoc !== null && planningMinimumSoc < minimumSoc) {
    warnings.push('Planning Minimum SoC is below the hard Minimum SoC.');
  }

  if (planningMaximumSoc !== null && planningMaximumSoc > 98) {
    warnings.push('Planning Maximum SoC above 98 % can reduce PV headroom noticeably.');
  }

  if (keepAliveSeconds !== null && keepAliveSeconds < 5) {
    warnings.push('Very short KeepAlive intervals can increase system noise.');
  }

  if (staleAfterSeconds !== null && staleAfterSeconds < 10) {
    warnings.push('Very short MQTT stale timeouts can cause avoidable safety fallbacks.');
  }

  return warnings;
});

const hasUnsavedChanges = computed(() => {
  return Object.keys(draftValues.value).some((key) => draftValues.value[key] !== initialValues.value[key]);
});

const canSave = computed(() => hasUnsavedChanges.value && draftValidationErrors.value.length === 0 && !isSaving.value);

const summaryItems = computed(() => {
  const totalCapacity = getNumericDraftValue('battery.totalCapacityKwh');
  const planningMinimumSoc = getNumericDraftValue('battery.planningMinimumStateOfChargePercent');
  const planningMaximumSoc = getNumericDraftValue('battery.planningMaximumStateOfChargePercent');
  const targetEndSoc = getNumericDraftValue('battery.targetEndStateOfChargePercent');
  const usablePlanningCapacity = totalCapacity !== null && planningMinimumSoc !== null && planningMaximumSoc !== null
    ? totalCapacity * ((planningMaximumSoc - planningMinimumSoc) / 100)
    : null;

  return [
    {
      label: 'Battery usable range',
      value: planningMinimumSoc !== null && planningMaximumSoc !== null
        ? `${formatPercentValue(planningMinimumSoc)} - ${formatPercentValue(planningMaximumSoc)}`
        : 'Not available'
    },
    {
      label: 'Target end SoC',
      value: targetEndSoc !== null ? formatPercentValue(targetEndSoc) : 'Not available'
    },
    {
      label: 'Forecast enabled',
      value: getDraftValue('pvForecast.provider') ? 'Enabled' : 'Disabled'
    },
    {
      label: 'Tibber token',
      value: isSettingConfigured('tibber.accessToken') ? 'Configured' : 'Missing'
    },
    {
      label: 'Shadow mode',
      value: getDraftValue('victron.dryRun') === 'true' ? 'Enabled' : 'Disabled'
    },
    {
      label: 'Usable planning capacity',
      value: usablePlanningCapacity !== null ? `${formatDecimal(usablePlanningCapacity, 2)} kWh` : 'Not available'
    }
  ];
});

async function loadPageData(): Promise<void> {
  isLoading.value = true;
  pageError.value = null;

  try {
    const [settingsResponse, metadataResponse, statusResponse] = await Promise.all([
      fetchJson<ControllerSettingsResponseDto>('/api/settings'),
      fetchJson<GuiMetadataResponseDto>('/api/gui/metadata'),
      fetchJson<ControllerStatusResponseDto>('/api/status')
    ]);

    settings.value = settingsResponse.settings;
    metadata.value = metadataResponse;
    status.value = statusResponse;
    initializeDrafts();
    saveSuccess.value = false;
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : 'Settings could not be loaded.';
  } finally {
    isLoading.value = false;
  }
}

async function saveSettings(): Promise<void> {
  if (!canSave.value) {
    return;
  }

  isSaving.value = true;
  pageError.value = null;
  saveSuccess.value = false;

  try {
    const changedKeys = Object.keys(draftValues.value).filter((key) => draftValues.value[key] !== initialValues.value[key]);

    for (const key of changedKeys) {
      const setting = settingByKey.value.get(key);

      if (!setting) {
        continue;
      }

      const payload = createUpdatePayload(setting, draftValues.value[key]);

      if (payload === null) {
        continue;
      }

      await fetchJson<ControllerSettingResponseDto>(`/api/settings/${encodeURIComponent(key)}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });
    }

    await loadPageData();
    saveSuccess.value = true;
  } catch (error) {
    pageError.value = error instanceof Error ? error.message : 'Settings could not be saved.';
  } finally {
    isSaving.value = false;
  }
}

function resetChanges(): void {
  draftValues.value = { ...initialValues.value };
  saveSuccess.value = false;
}

function getDraftValue(key: string): string {
  return draftValues.value[key] ?? '';
}

function getNumericDraftValue(key: string): number | null {
  const rawValue = getDraftValue(key).trim();

  if (rawValue === '') {
    return null;
  }

  const parsedValue = Number(rawValue.replace(',', '.'));

  return Number.isFinite(parsedValue) ? parsedValue : null;
}

function getFieldErrors(key: string): string[] {
  const errors: string[] = [];
  const numericValue = getNumericDraftValue(key);

  if (requiredKeys.has(key) && !isSettingConfigured(key) && getDraftValue(key).trim() === '') {
    errors.push('This setting is required.');
  }

  switch (key) {
    case 'battery.totalCapacityKwh':
      if (numericValue !== null && numericValue <= 0) {
        errors.push('Must be greater than 0.');
      }
      break;
    case 'battery.minimumStateOfChargePercent':
      if (numericValue !== null && (numericValue < 0 || numericValue > 100)) {
        errors.push('Must be between 0 and 100.');
      }
      break;
    case 'battery.planningMinimumStateOfChargePercent': {
      const minimumSoc = getNumericDraftValue('battery.minimumStateOfChargePercent');
      if (numericValue !== null && minimumSoc !== null && numericValue < minimumSoc) {
        errors.push('Must be greater than or equal to Minimum SoC.');
      }
      break;
    }
    case 'battery.planningMaximumStateOfChargePercent': {
      const planningMinimumSoc = getNumericDraftValue('battery.planningMinimumStateOfChargePercent');
      if (numericValue !== null && numericValue > 100) {
        errors.push('Must be less than or equal to 100.');
      }
      if (numericValue !== null && planningMinimumSoc !== null && numericValue <= planningMinimumSoc) {
        errors.push('Must be greater than Planning Minimum SoC.');
      }
      break;
    }
    case 'battery.targetEndStateOfChargePercent': {
      const planningMinimumSoc = getNumericDraftValue('battery.planningMinimumStateOfChargePercent');
      const planningMaximumSoc = getNumericDraftValue('battery.planningMaximumStateOfChargePercent');
      if (
        numericValue !== null &&
        planningMinimumSoc !== null &&
        planningMaximumSoc !== null &&
        (numericValue < planningMinimumSoc || numericValue > planningMaximumSoc)
      ) {
        errors.push('Must stay within the planning range.');
      }
      break;
    }
    case 'battery.roundTripEfficiencyPercent':
      if (numericValue !== null && (numericValue < 50 || numericValue > 100)) {
        errors.push('Must be between 50 and 100.');
      }
      break;
    case 'battery.maximumChargePowerWatts':
    case 'battery.maximumDischargePowerWatts':
      if (numericValue !== null && numericValue <= 0) {
        errors.push('Must be greater than 0.');
      }
      break;
  }

  return errors;
}

function getCategoryColor(category: FieldDefinition['category']): string {
  if (category === 'Safety Critical') {
    return 'warning';
  }

  if (category === 'Important') {
    return 'secondary';
  }

  return 'default';
}

function isSettingConfigured(key: string): boolean {
  const setting = settingByKey.value.get(key);

  if (!setting) {
    return getDraftValue(key).trim() !== '';
  }

  if (setting.isSensitive) {
    return setting.isConfigured || getDraftValue(key).trim() !== '';
  }

  return getDraftValue(key).trim() !== '';
}

function formatActivationHint(): string {
  return 'Changes become active on the next evaluation cycle. Runtime-related values may require a reconnect or the next scheduler pass.';
}

function formatPercentValue(value: number): string {
  return `${formatDecimal(value, 1)} %`;
}

function formatDecimal(value: number, digits: number): string {
  return new Intl.NumberFormat('en-US', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(value);
}

function initializeDrafts(): void {
  const nextDrafts: Record<string, string> = {};

  for (const [key, metadataEntry] of metadataByKey.value.entries()) {
    const setting = settingByKey.value.get(key);

    if (setting?.isSensitive) {
      nextDrafts[key] = '';
      continue;
    }

    nextDrafts[key] = setting?.value ?? metadataEntry.defaultValue ?? '';
  }

  draftValues.value = nextDrafts;
  initialValues.value = { ...nextDrafts };
}

async function fetchJson<TResponse>(url: string, requestInit?: RequestInit): Promise<TResponse> {
  const response = await fetch(url, requestInit);

  if (!response.ok) {
    const error = (await response.json().catch(() => null)) as SettingsErrorDto | null;
    throw new Error(error?.message ?? `Request failed with HTTP ${response.status}.`);
  }

  return (await response.json()) as TResponse;
}

function createUpdatePayload(setting: ControllerSettingResponseDto, rawValue: string): UpdateControllerSettingRequestDto | null {
  const trimmedValue = rawValue.trim();

  if (setting.isSensitive) {
    if (trimmedValue === '' && setting.isConfigured) {
      return null;
    }

    return { value: trimmedValue === '' ? null : trimmedValue };
  }

  return { value: trimmedValue === '' ? null : trimmedValue };
}

onMounted(() => {
  void loadPageData();
});
</script>

<template>
  <v-container class="settings-page" fluid>
    <div class="page-header">
      <div>
        <span class="page-header__eyebrow">Configuration</span>
        <h1>Settings</h1>
        <p>Konfiguration für Batterie, Preise, Forecasts und Systemverhalten</p>
      </div>
      <div class="page-header__status">
        <v-chip
          :color="hasUnsavedChanges ? 'warning' : 'success'"
          size="small"
          variant="flat"
        >
          {{ hasUnsavedChanges ? 'Unsaved changes' : 'Saved' }}
        </v-chip>
        <span>{{ formatActivationHint() }}</span>
      </div>
    </div>

    <v-alert
      v-if="pageError"
      class="mb-4"
      type="error"
      variant="tonal"
    >
      {{ pageError }}
    </v-alert>

    <v-alert
      v-if="status?.victronMqttLastError"
      class="mb-4"
      type="warning"
      variant="tonal"
    >
      {{ status.victronMqttLastError }}
    </v-alert>

    <v-alert
      v-if="saveSuccess"
      class="mb-4"
      type="success"
      variant="tonal"
    >
      Settings saved successfully.
    </v-alert>

    <v-alert
      v-if="draftValidationErrors.length > 0"
      class="mb-4"
      type="error"
      variant="tonal"
    >
      <strong>Validation errors</strong>
      <ul class="message-list">
        <li v-for="error in draftValidationErrors" :key="error">{{ error }}</li>
      </ul>
    </v-alert>

    <v-alert
      v-if="warningMessages.length > 0"
      class="mb-4"
      type="warning"
      variant="tonal"
    >
      <strong>Warnings</strong>
      <ul class="message-list">
        <li v-for="warning in warningMessages" :key="warning">{{ warning }}</li>
      </ul>
    </v-alert>

    <div class="settings-layout">
      <div class="settings-main">
        <v-card
          v-for="section in sections"
          :key="section.key"
          class="settings-card"
          elevation="0"
        >
          <div class="settings-card__header">
            <div>
              <h2>{{ section.title }}</h2>
              <p>{{ section.description }}</p>
            </div>
          </div>

          <div
            v-if="section.key === 'battery'"
            class="section-note"
          >
            Planning limits are used by the forecast engine. Absolute limits are used as hard safety constraints.
          </div>

          <v-row class="settings-fields">
            <v-col
              v-for="field in section.fields"
              :key="field.key"
              cols="12"
              md="6"
            >
              <div
                class="field-card"
                :class="{
                  'field-card--important': field.category === 'Important',
                  'field-card--critical': field.category === 'Safety Critical'
                }"
              >
                <div class="field-card__top">
                  <div>
                    <label class="field-card__label" :for="field.key">
                      {{ metadataByKey.get(field.key)?.displayName ?? field.key }}
                    </label>
                    <p class="field-card__description">
                      {{ field.helperText ?? metadataByKey.get(field.key)?.description }}
                    </p>
                  </div>
                  <v-chip
                    :color="getCategoryColor(field.category)"
                    size="x-small"
                    variant="tonal"
                  >
                    {{ field.category }}
                  </v-chip>
                </div>

                <v-text-field
                  :id="field.key"
                  v-model="draftValues[field.key]"
                  :type="metadataByKey.get(field.key)?.isSensitive ? 'password' : metadataByKey.get(field.key)?.inputKind === 'number' ? 'number' : 'text'"
                  :suffix="metadataByKey.get(field.key)?.unit ?? undefined"
                  :placeholder="metadataByKey.get(field.key)?.defaultValue ?? undefined"
                  :hint="metadataByKey.get(field.key)?.isSensitive && settingByKey.get(field.key)?.isConfigured ? 'Stored securely. Leave blank to keep the existing secret.' : undefined"
                  :persistent-hint="metadataByKey.get(field.key)?.isSensitive && settingByKey.get(field.key)?.isConfigured"
                  :error-messages="getFieldErrors(field.key)"
                  hide-details="auto"
                  variant="outlined"
                />
              </div>
            </v-col>
          </v-row>
        </v-card>
      </div>

      <aside class="settings-sidebar">
        <v-card class="summary-card" elevation="0">
          <div class="summary-card__header">
            <h2>Summary</h2>
            <p>Quick check of the current planning profile.</p>
          </div>

          <div class="summary-list">
            <div
              v-for="item in summaryItems"
              :key="item.label"
              class="summary-item"
            >
              <span>{{ item.label }}</span>
              <strong>{{ item.value }}</strong>
            </div>
          </div>
        </v-card>

        <v-card class="summary-card" elevation="0">
          <div class="summary-card__header">
            <h2>System status</h2>
            <p>Runtime and connectivity information.</p>
          </div>

          <div class="summary-list">
            <div class="summary-item">
              <span>Controller</span>
              <strong>{{ status?.status ?? 'Unknown' }}</strong>
            </div>
            <div class="summary-item">
              <span>Victron MQTT</span>
              <strong>{{ status?.victronMqttStatus ?? 'Unknown' }}</strong>
            </div>
            <div class="summary-item">
              <span>Configured secrets</span>
              <strong>{{ status?.configuredSensitiveSettingsCount ?? 0 }}</strong>
            </div>
          </div>
        </v-card>
      </aside>
    </div>

    <div class="action-bar">
      <div class="action-bar__copy">
        <strong>{{ hasUnsavedChanges ? 'Unsaved changes present' : 'All settings are in sync' }}</strong>
        <span>Save writes the current draft to the controller database.</span>
      </div>

      <div class="action-bar__buttons">
        <v-btn
          variant="text"
          :disabled="isSaving || !hasUnsavedChanges"
          @click="resetChanges"
        >
          Reset Changes
        </v-btn>
        <v-btn
          variant="text"
          :disabled="isLoading || isSaving"
          @click="loadPageData"
        >
          Reload Current Settings
        </v-btn>
        <v-btn
          color="primary"
          :disabled="!canSave"
          :loading="isSaving"
          prepend-icon="mdi-content-save"
          @click="saveSettings"
        >
          Save Settings
        </v-btn>
      </div>
    </div>
  </v-container>
</template>

<style scoped>
.settings-page {
  max-width: 1560px;
  padding: 28px;
}

.page-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 20px;
  margin-bottom: 24px;
}

.page-header__eyebrow {
  color: #64748b;
  font-size: 0.74rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.page-header h1 {
  margin: 8px 0 6px;
  color: #172026;
  font-size: 2rem;
  line-height: 1.15;
}

.page-header p,
.page-header__status span {
  margin: 0;
  color: #64748b;
  line-height: 1.5;
}

.page-header__status {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 8px;
  max-width: 360px;
}

.message-list {
  margin: 8px 0 0;
  padding-left: 18px;
}

.settings-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 340px;
  gap: 20px;
}

.settings-main {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.settings-sidebar {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.settings-card,
.summary-card {
  border: 1px solid rgba(214, 223, 230, 0.9);
  border-radius: 18px;
  background: rgba(255, 255, 255, 0.9);
  box-shadow: 0 18px 34px rgba(23, 32, 38, 0.05);
}

.settings-card__header,
.summary-card__header {
  padding: 22px 24px 0;
}

.settings-card__header h2,
.summary-card__header h2 {
  margin: 0 0 6px;
  color: #172026;
  font-size: 1.15rem;
}

.settings-card__header p,
.summary-card__header p {
  margin: 0;
  color: #64748b;
  line-height: 1.45;
}

.section-note {
  margin: 18px 24px 0;
  padding: 14px 16px;
  border: 1px solid rgba(31, 111, 120, 0.14);
  border-radius: 14px;
  background: rgba(31, 111, 120, 0.06);
  color: #36515a;
  line-height: 1.5;
}

.settings-fields {
  padding: 12px 12px 18px;
}

.field-card {
  height: 100%;
  padding: 16px;
  border: 1px solid rgba(220, 227, 233, 0.95);
  border-radius: 16px;
  background: #fbfcfd;
}

.field-card--important {
  border-color: rgba(68, 84, 106, 0.22);
  background: rgba(68, 84, 106, 0.04);
}

.field-card--critical {
  border-color: rgba(183, 121, 31, 0.24);
  background: rgba(183, 121, 31, 0.05);
}

.field-card__top {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
}

.field-card__label {
  display: block;
  margin-bottom: 6px;
  color: #172026;
  font-size: 0.96rem;
  font-weight: 700;
}

.field-card__description {
  margin: 0;
  color: #64748b;
  line-height: 1.45;
}

.summary-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 18px 24px 24px;
}

.summary-item {
  padding: 14px 16px;
  border: 1px solid rgba(220, 227, 233, 0.95);
  border-radius: 14px;
  background: #fbfcfd;
}

.summary-item span,
.summary-item strong {
  display: block;
}

.summary-item span {
  color: #64748b;
  font-size: 0.82rem;
  margin-bottom: 6px;
}

.summary-item strong {
  color: #172026;
  font-size: 1rem;
}

.action-bar {
  position: sticky;
  bottom: 18px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  margin-top: 24px;
  padding: 16px 20px;
  border: 1px solid rgba(214, 223, 230, 0.95);
  border-radius: 18px;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(14px);
  box-shadow: 0 18px 36px rgba(23, 32, 38, 0.08);
}

.action-bar__copy strong,
.action-bar__copy span {
  display: block;
}

.action-bar__copy strong {
  color: #172026;
  margin-bottom: 4px;
}

.action-bar__copy span {
  color: #64748b;
}

.action-bar__buttons {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 10px;
}

@media (max-width: 1200px) {
  .settings-layout {
    grid-template-columns: 1fr;
  }

  .settings-sidebar {
    order: -1;
  }
}

@media (max-width: 760px) {
  .settings-page {
    padding: 16px;
  }

  .page-header,
  .action-bar {
    flex-direction: column;
    align-items: stretch;
  }

  .page-header__status {
    align-items: flex-start;
    max-width: none;
  }

  .action-bar__buttons {
    justify-content: stretch;
  }
}
</style>
