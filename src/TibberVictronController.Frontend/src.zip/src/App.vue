<script setup lang="ts">
import { computed } from 'vue';
import { useRoute, useRouter } from 'vue-router';

interface NavigationItem {
  title: string;
  subtitle: string;
  routeName: string;
}

const router = useRouter();
const route = useRoute();

const navigationItems: NavigationItem[] = [
  {
    title: 'Settings',
    subtitle: 'Battery, prices, forecasts and safety',
    routeName: 'settings'
  }
];

const activeRouteName = computed(() => String(route.name ?? ''));

function navigateTo(routeName: string): void {
  void router.push({ name: routeName });
}
</script>

<template>
  <v-app class="app-shell">
    <v-app-bar class="top-bar" elevation="0">
      <div class="top-bar__copy">
        <span class="top-bar__eyebrow">Tibber Victron Controller</span>
        <strong>Energy Control</strong>
      </div>
    </v-app-bar>

    <v-navigation-drawer
      class="side-rail"
      color="transparent"
      elevation="0"
      permanent
      width="280"
    >
      <div class="brand-panel">
        <span class="brand-panel__eyebrow">Control Center</span>
        <h1>Battery Controller</h1>
        <p>Operational settings for battery, price logic, forecasting and system safety.</p>
      </div>

      <nav class="nav-list" aria-label="Main navigation">
        <button
          v-for="item in navigationItems"
          :key="item.routeName"
          class="nav-item"
          :class="{ 'nav-item--active': activeRouteName === item.routeName }"
          @click="navigateTo(item.routeName)"
        >
          <span>{{ item.title }}</span>
          <small>{{ item.subtitle }}</small>
        </button>
      </nav>
    </v-navigation-drawer>

    <v-main>
      <router-view />
    </v-main>
  </v-app>
</template>

<style scoped>
.app-shell {
  background:
    radial-gradient(circle at top left, rgba(31, 111, 120, 0.08), transparent 28%),
    linear-gradient(180deg, #f7f9fc 0%, #eef2f6 100%);
}

.top-bar {
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(214, 223, 230, 0.8);
}

.top-bar__copy {
  display: flex;
  flex-direction: column;
  line-height: 1.2;
}

.top-bar__copy strong {
  color: #172026;
  font-size: 1rem;
}

.top-bar__eyebrow {
  color: #64748b;
  font-size: 0.74rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.side-rail {
  padding: 16px;
}

.brand-panel {
  margin: 12px;
  padding: 22px;
  border: 1px solid rgba(214, 223, 230, 0.8);
  border-radius: 18px;
  background: linear-gradient(155deg, #18353a 0%, #1f6f78 100%);
  color: #ffffff;
  box-shadow: 0 18px 36px rgba(23, 32, 38, 0.12);
}

.brand-panel__eyebrow {
  color: rgba(255, 255, 255, 0.76);
  font-size: 0.72rem;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}

.brand-panel h1 {
  margin: 10px 0 8px;
  font-size: 1.35rem;
  line-height: 1.25;
}

.brand-panel p {
  margin: 0;
  color: rgba(255, 255, 255, 0.8);
  line-height: 1.5;
}

.nav-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin: 18px 12px 0;
}

.nav-item {
  border: 1px solid rgba(214, 223, 230, 0.9);
  border-radius: 14px;
  background: rgba(255, 255, 255, 0.88);
  padding: 14px 16px;
  text-align: left;
  cursor: pointer;
  transition:
    transform 0.18s ease,
    border-color 0.18s ease,
    background-color 0.18s ease;
}

.nav-item span,
.nav-item small {
  display: block;
}

.nav-item span {
  color: #172026;
  font-weight: 700;
  margin-bottom: 4px;
}

.nav-item small {
  color: #64748b;
}

.nav-item:hover {
  transform: translateY(-1px);
  border-color: rgba(31, 111, 120, 0.3);
}

.nav-item--active {
  background: rgba(31, 111, 120, 0.08);
  border-color: rgba(31, 111, 120, 0.34);
}

@media (max-width: 960px) {
  .side-rail {
    display: none;
  }
}
</style>
